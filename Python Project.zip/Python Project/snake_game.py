import pygame
import time
import random

# Initialize pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
LIGHT_GREEN = (144, 238, 144)
DARK_GREEN = (34, 139, 34)
PURPLE = (128, 0, 128)
DARK_BLUE = (0, 0, 128)

# Snake block size and speed
BLOCK_SIZE = 20
SPEED = 6

# Initialize screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Snake Game")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

# Font styles
font_style = pygame.font.SysFont("bahnschrift", 25)
score_font = pygame.font.SysFont("comicsansms", 35)
title_font = pygame.font.SysFont("comicsansms", 40)  # Reduced size for the title

def display_score(score):
    value = score_font.render(f"Your Score: {score}", True, GREEN)
    screen.blit(value, [10, 10])

def draw_background():
    for i in range(HEIGHT):
        # Smooth gradient from dark blue to purple
        color = (int(DARK_BLUE[0] + (PURPLE[0] - DARK_BLUE[0]) * i / HEIGHT),
                 int(DARK_BLUE[1] + (PURPLE[1] - DARK_BLUE[1]) * i / HEIGHT),
                 int(DARK_BLUE[2] + (PURPLE[2] - DARK_BLUE[2]) * i / HEIGHT))
        pygame.draw.line(screen, color, (0, i), (WIDTH, i))

def draw_snake(block_size, snake_list, direction):
    for i, block in enumerate(snake_list):
        if i == len(snake_list) - 1:  # Snake head
            pygame.draw.ellipse(screen, YELLOW, [block[0], block[1], block_size, block_size])
            
            # Draw the tongue in the direction of movement
            if direction == 'UP':
                pygame.draw.line(screen, RED, (block[0] + block_size // 2, block[1] + block_size // 2),
                                 (block[0] + block_size // 2, block[1] - 10), 2)
            elif direction == 'DOWN':
                pygame.draw.line(screen, RED, (block[0] + block_size // 2, block[1] + block_size // 2),
                                 (block[0] + block_size // 2, block[1] + block_size + 10), 2)
            elif direction == 'LEFT':
                pygame.draw.line(screen, RED, (block[0] + block_size // 2, block[1] + block_size // 2),
                                 (block[0] - 10, block[1] + block_size // 2), 2)
            elif direction == 'RIGHT':
                pygame.draw.line(screen, RED, (block[0] + block_size // 2, block[1] + block_size // 2),
                                 (block[0] + block_size + 10, block[1] + block_size // 2), 2)

            # Draw eyes
            pygame.draw.circle(screen, WHITE, (block[0] + block_size // 4, block[1] + block_size // 4), block_size // 5)
            pygame.draw.circle(screen, BLACK, (block[0] + block_size // 4, block[1] + block_size // 4), block_size // 8)

            pygame.draw.circle(screen, WHITE, (block[0] + 3 * block_size // 4, block[1] + block_size // 4), block_size // 5)
            pygame.draw.circle(screen, BLACK, (block[0] + 3 * block_size // 4, block[1] + block_size // 4), block_size // 8)

        else:
            # Snake body with stripes
            if i % 2 == 0:
                pygame.draw.ellipse(screen, GREEN, [block[0], block[1], block_size, block_size])
            else:
                pygame.draw.ellipse(screen, BLUE, [block[0], block[1], block_size, block_size])

            pygame.draw.circle(screen, WHITE, (block[0] + block_size // 4, block[1] + block_size // 4), block_size // 8)  # Spot

def message(msg, color, y_offset=0, font_size=25):
    font = pygame.font.SysFont("comicsansms", font_size)
    msg_surface = font.render(msg, True, color)
    screen.blit(msg_surface, [WIDTH / 6, HEIGHT / 3 + y_offset])

def countdown():
    for i in range(3, 0, -1):
        screen.fill(BLACK)
        message(f"Starting in {i}...", YELLOW, 0, 50)
        pygame.display.update()
        time.sleep(1)

    screen.fill(BLACK)
    message("Go!", GREEN, 0, 50)
    message("(Press any direction key to move the snake)", LIGHT_GREEN, 50, 20)  # New instruction
    pygame.display.update()
    time.sleep(1)

def is_food_on_snake(snake_list, food_x, food_y):
    for block in snake_list:
        if block[0] == food_x and block[1] == food_y:
            return True
    return False

def draw_game_over(score):
    screen.fill(BLACK)
    message(f"Game Over! Your Score: {score}", RED, -50, 40)
    message("Press Enter to Restart", YELLOW, 50, 30)
    pygame.display.update()

def welcome_screen():
    screen.fill(BLACK)
    message("Welcome to the Snake Game", YELLOW, -80, 40)  # Reduced size
    message("Press Enter to Start", LIGHT_GREEN, 0, 30)
    pygame.display.update()

def game_loop():
    game_over = False
    game_close = False

    x1, y1 = WIDTH / 2, HEIGHT / 2
    x1_change, y1_change = 0, 0
    direction = 'UP'  # Initial direction

    snake_list = []
    length_of_snake = 1

    food_x = round(random.randrange(0, WIDTH - BLOCK_SIZE) / 20.0) * 20.0
    food_y = round(random.randrange(0, HEIGHT - BLOCK_SIZE) / 20.0) * 20.0

    while is_food_on_snake(snake_list, food_x, food_y):
        food_x = round(random.randrange(0, WIDTH - BLOCK_SIZE) / 20.0) * 20.0
        food_y = round(random.randrange(0, HEIGHT - BLOCK_SIZE) / 20.0) * 20.0

    # Wait for Enter key to start
    waiting_for_start = True
    while waiting_for_start:
        welcome_screen()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Press Enter to start
                    waiting_for_start = False

    # Countdown before starting the game
    countdown()

    while not game_over:

        while game_close:
            draw_game_over(length_of_snake - 1)

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:  # Restart the game when Enter is pressed
                        game_loop()  # Start the game loop again

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and x1_change == 0:
                    x1_change = -BLOCK_SIZE
                    y1_change = 0
                    direction = 'LEFT'
                elif event.key == pygame.K_RIGHT and x1_change == 0:
                    x1_change = BLOCK_SIZE
                    y1_change = 0
                    direction = 'RIGHT'
                elif event.key == pygame.K_UP and y1_change == 0:
                    x1_change = 0
                    y1_change = -BLOCK_SIZE
                    direction = 'UP'
                elif event.key == pygame.K_DOWN and y1_change == 0:
                    x1_change = 0
                    y1_change = BLOCK_SIZE
                    direction = 'DOWN'

        if x1 >= WIDTH or x1 < 0 or y1 >= HEIGHT or y1 < 0:
            game_close = True

        x1 += x1_change
        y1 += y1_change
        screen.fill(BLACK)

        # Draw background gradient
        draw_background()

        pygame.draw.rect(screen, GREEN, [food_x, food_y, BLOCK_SIZE, BLOCK_SIZE])

        snake_head = [x1, y1]
        snake_list.append(snake_head)
        if len(snake_list) > length_of_snake:
            del snake_list[0]

        for block in snake_list[:-1]:
            if block == snake_head:
                game_close = True

        draw_snake(BLOCK_SIZE, snake_list, direction)
        display_score(length_of_snake - 1)

        pygame.display.update()

        if x1 == food_x and y1 == food_y:
            food_x = round(random.randrange(0, WIDTH - BLOCK_SIZE) / 20.0) * 20.0
            food_y = round(random.randrange(0, HEIGHT - BLOCK_SIZE) / 20.0) * 20.0
            while is_food_on_snake(snake_list, food_x, food_y):
                food_x = round(random.randrange(0, WIDTH - BLOCK_SIZE) / 20.0) * 20.0
                food_y = round(random.randrange(0, HEIGHT - BLOCK_SIZE) / 20.0) * 20.0
            length_of_snake += 1

        clock.tick(SPEED)

    pygame.quit()
    quit()

# Start the game
game_loop()
